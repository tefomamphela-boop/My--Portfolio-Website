---
name: Tefo Mamphela Portfolio
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#b9c8de'
  on-secondary: '#233143'
  secondary-container: '#39485a'
  on-secondary-container: '#a7b6cc'
  tertiary: '#bfc6dd'
  on-tertiary: '#293042'
  tertiary-container: '#8990a6'
  on-tertiary-container: '#22293b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#d4e4fa'
  secondary-fixed-dim: '#b9c8de'
  on-secondary-fixed: '#0d1c2d'
  on-secondary-fixed-variant: '#39485a'
  tertiary-fixed: '#dbe2fa'
  tertiary-fixed-dim: '#bfc6dd'
  on-tertiary-fixed: '#141b2c'
  on-tertiary-fixed-variant: '#3f4759'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality is authoritative, refined, and distinctly modern. Designed for Tefo Mamphela's personal portfolio, the aesthetic positions him as a senior, visionary practitioner through deliberate restraint, editorial clarity, and impeccable craftsmanship. 

The visual style synthesizes modern editorial minimalism with subtle tactile depth. It avoids gimmicks, relying on generous negative space, intentional hierarchy, razor-sharp typography, and delicate luminous borders against rich, muted slate tones. The experience communicates intellectual rigor, quiet confidence, and technical precision.

## Colors

The system uses a dark canvas inspired by deep midnight slate (`#0B0F17`), enriched by subtle warm indigo accents (`#6366F1`) and misted slate neutrals (`#94A3B8`). 

- **Canvas & Surfaces:**
  - Base Background: `#0B0F17` (Deep obsidian slate)
  - Surface Tier 1 (Cards, Elevated Containers): `#111827`
  - Surface Tier 2 (Interactive surfaces, Hover states): `#1E293B`
  - Surface Border / Ghost Lines: `rgba(148, 163, 184, 0.12)`
- **Brand & Accent:**
  - Primary Indigo Accent: `#6366F1` (Used strategically for primary CTAs, active indicators, and high-impact metadata)
  - Primary Hover / Glow: `#4F46E5`
  - Tertiary Ice Indigo: `#E0E7FF` (Used for high-visibility badges, tags, and focal points)
- **Content Contrast:**
  - High-Emphasis Text: `#F8FAFC`
  - Body & Descriptive Text: `#94A3B8`
  - Subdued / Metric Labels: `#64748B`

## Typography

Typography balances structural personality with rigorous clarity. Plus Jakarta Sans lends editorial presence to titles and display metrics, sporting tight letter-spacing for a modern, confident tone. Inter anchors all body copy and metadata, ensuring exceptional readability at all viewports.

- Use uppercase tracking (`0.05em`) exclusively with `label-sm` for category tags, timeline dates, and status pills.
- Headline scales enforce tight negative letter-spacing to prevent loose visual weight on dark backgrounds.
- Reading measures should remain capped at 65 characters per line for long-form case studies.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid system on desktop (max width `1200px`) and transitions gracefully to a 4-column system on mobile devices.

- **Breakpoints:**
  - Mobile: `< 640px` (4 columns, `margin-mobile: 1.25rem`, `gutter-mobile: 1rem`)
  - Tablet: `640px – 1023px` (8 columns, `margin: 2rem`, `gutter: 1.5rem`)
  - Desktop: `≥ 1024px` (12 columns, `margin: 3rem`, `gutter: 1.5rem`)
- **Vertical Rhythm:** Sections are partitioned by high-contrast breathing room (`space-xl` multiplied by 2 to 3 for desktop page section blocks) to reinforce the unhurried, gallery-level editorial feel.

## Elevation & Depth

Visual hierarchy on dark slate surfaces relies on layered luminosity and low-contrast perimeter borders rather than heavy drop shadows:

- **Surface Layering:**
  - Level 0 (Base Canvas): `#0B0F17`
  - Level 1 (Static Cards / Modules): `#111827` enclosed with a single 1px hairline border of `rgba(148, 163, 184, 0.12)`.
  - Level 2 (Hover & Elevated Overlays): `#1E293B` coupled with an ambient perimeter glow: `0 12px 32px -8px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(99, 102, 241, 0.25)`.
- **Accents:** Active elements and focal hover cards receive a subtle, directional inner rim light (`inset 0 1px 0 0 rgba(255, 255, 255, 0.08)`) simulating light casting from the top of the viewport.

## Shapes

The design system employs a disciplined, balanced geometry (Level 2).
- Default components (buttons, text inputs, timeline chips) take `0.5rem` (8px).
- Content containers, case study previews, and profile cards utilize `1rem` (16px).
- Hero stat badges and modal containers leverage `1.5rem` (24px).
- Pill shapes are reserved exclusively for status indicators, active filters, and skill badges.

## Components

### Buttons
- **Primary:** Solid `#6366F1` background, `#FFFFFF` text, `0.5rem` border radius. On hover: background `#4F46E5` with an ambient glow (`box-shadow: 0 4px 14px rgba(99, 102, 241, 0.35)`).
- **Secondary / Ghost:** `rgba(148, 163, 184, 0.08)` surface, 1px border of `rgba(148, 163, 184, 0.16)`, `#F8FAFC` text. On hover: surface changes to `rgba(148, 163, 184, 0.15)`.

### Cards & Project Showcases
- Card backgrounds use Surface Tier 1 (`#111827`) with `1rem` border radius and a 1px border (`rgba(148, 163, 184, 0.12)`).
- Hover transitions should smoothly translate `2px` upward on the Y-axis accompanied by the Level 2 indigo halo border.

### Badges & Chips
- Designed with pill geometry or `0.25rem` micro-radius.
- Muted slate variant: `background: rgba(148, 163, 184, 0.1)`, `color: #94A3B8`, border `1px solid rgba(148, 163, 184, 0.15)`.
- Featured/Active variant: `background: rgba(99, 102, 241, 0.12)`, `color: #E0E7FF`, border `1px solid rgba(99, 102, 241, 0.3)`.

### Career Milestone Timeline
- Continuous 1px vertical guide rail rendered in `rgba(148, 163, 184, 0.16)`.
- Milestone nodes are represented by an 8px circular pip in `#6366F1` with an outer ring in `rgba(99, 102, 241, 0.2)`.
- Date indicators use `label-sm` with upper tracking, stacked directly beside the role title and organizational credential.

### Input Fields (Contact & Inquiries)
- Surface: `#0B0F17` background with 1px border `rgba(148, 163, 184, 0.2)`.
- Focus state: border color transitions to `#6366F1` with a zero-offset outline: `0 0 0 1px #6366F1`.